/** Automatically generated file. DO NOT MODIFY */
package com.mobinius.fblogin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}